<?php
	include"../../db.php";
	$kategori = $_POST['kategori'];
	mysqli_query($GLOBALS["___mysqli_ston"], "INSERT into kategori set kategori='$kategori'");
	header("location:kategori.php");
?>