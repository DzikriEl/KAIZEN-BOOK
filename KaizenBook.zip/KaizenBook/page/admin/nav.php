<div class="hdnavadmin">
Navigasi
</div>
<ul class="navadmin">
	<li><a href="index.php?page=home"><span class="glyphicon glyphicon-home"></span> Beranda</a></li>
	<li><a href="kategori.php"><span class="glyphicon glyphicon-list"></span> Kategori</a></li>
	<li><a href="katalog.php"><span class="glyphicon glyphicon-list"></span> Katalog</a></li>
	<li><a href="buku.php"><span class="glyphicon glyphicon-book"></span> Buku</a></li>
	<li><a href="customer.php"><span class="glyphicon glyphicon-user"></span> Customer</a></li>
	<li><a href="transaksi.php"><span class="glyphicon glyphicon-question-sign"></span> Transaksi</a></li>
	<li><a href="pengiriman.php"><span class="glyphicon glyphicon-question-sign"></span> Pengiriman buku</a></li>
	<li><a href="keluar.php"><span class="glyphicon glyphicon-log-out"></span> Keluar</a></li>
</ul>