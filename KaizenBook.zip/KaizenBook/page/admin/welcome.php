<div class="jumbotron">
	<div class="row">
	<div class="col-md-1">
	</div>
	<div class="col-md-9">
	<p style="font-size:20px;">Selamat Datang <?php echo "<b style='font-size:20px;'>".$nama."</b>"; ?> ,
	Anda saat ini berada di dashboard Admin Aplikasi Toko Online (Bakolbuku.com)</p>
	</div>
	</div>
</div>