<?php
include"../../db.php";
$kd=$_GET['id'];
$qry=mysqli_query($GLOBALS["___mysqli_ston"], "DELETE FROM customer WHERE id_cus='$kd'");
header('location:customer.php');
?>