<?php
	include"../../db.php";
	$kategori = $_POST['kategori'];
	$id_katego = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * from kategori where kategori='$kategori'");
	$id_kategor = mysqli_fetch_array($id_katego);
	$id_kategori = $id_kategor['id_kategori'];
	$katalog = $_POST['katalog'];
	mysqli_query($GLOBALS["___mysqli_ston"], "INSERT into katalog set id_kategori='$id_kategori',katalog='$katalog'");
	header("location:katalog.php");
?>