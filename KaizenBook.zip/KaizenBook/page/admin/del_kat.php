<?php
	include "../../db.php";
	$kd=$_GET['id'];
	$qry=mysqli_query($GLOBALS["___mysqli_ston"], "DELETE FROM kategori WHERE id_kategori='$kd'");
	header('location:kategori.php');
?>