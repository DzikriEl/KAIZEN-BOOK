<div class="jumbotron">
<center>
<div class="hdlogin">
Silahkan Login untuk memulai
</div>
<form action="actlogin.php" method="post">
	<div class="login">
	<div class="form-group">
	<input type="text" name="email" class="form-control" placeholder="email anda" style="margin:10px;">
	<input type="password" name="password" class="form-control" placeholder="password anda" style="margin:10px;">
	<input type="submit" name="login" value="masuk" class="form-control" style="margin:10px;background:#0000ff;color:#fff;">
	</div>
	</div>
</form>
<b>belum punya akun?<a href="index.php?act=daftar"> daftar</a></b>
</center>
</div>