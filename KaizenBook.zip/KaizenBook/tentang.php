<div class="hdproduk">
Tentang Kami
</div>
<div class="jumbotron">
<div style="margin-left:50px;">
<p>Kaizen Bookstore adalah Proyek Tugas Software Testing.<br> Toko Buku Online Berbasis Web. </p>
    <p>Nama Kelompok :</p>
    <p>1. Ahmad Kamal       (065118121)</p>
    <p>2. Dzikri Faizziyan  (065118123)</p>
    <p>3. Syaugi            (065118126)</p>
    </div>
</div>