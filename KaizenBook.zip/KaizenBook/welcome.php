<div class="jumbotron">
	<div class="row">
	<div class="col-md-3">
	<img src="img/Kaizenbuku.png">
	</div>
	<div class="col-md-8">
    <h1>KaizenBook.com</h1>
    <p class="lead">Kaizen Bookstore adalah Proyek Tugas Software Testing.</p>
    <p><a class="btn btn-lg btn-success" href="#" role="button">Beli Sekarang</a></p>
    </div>
    </div>
</div>