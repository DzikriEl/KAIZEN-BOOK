<?php
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost", "root", "")) or die (mysqli_error($GLOBALS["___mysqli_ston"]));
mysqli_select_db($GLOBALS["___mysqli_ston"], 'muhammad_abdullah') or die ("Database tidak tersedia");
?>